Python 3.6.2 (v3.6.2:5fd33b5, Jul  8 2017, 04:57:36) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import lightgbm as lgb
import xgboost as xgb
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import classification_report

custom_palette = sns.color_palette("Set2")

# Assuming dfPhase is defined earlier

X = pd.get_dummies(dfPhase.drop(columns=['class']))
y = dfPhase['class']

y_binary = y.replace({'anomaly': 0, 'normal': 1})

X_train, X_test, y_train_binary, y_test_binary = train_test_split(X, y_binary, test_size=0.2, random_state=42)

X_train.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
X_test.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]

# LightGBM model
lgb_model = lgb.LGBMClassifier(verbosity=-1)  # Setting verbosity to -1 suppresses warnings
lgb_model.fit(X_train, y_train_binary)

# XGBoost model
xgb_model = xgb.XGBClassifier(verbosity=0)  # Setting verbosity to 0 suppresses warnings
xgb_model.fit(X_train, y_train_binary)

# Create ensemble model using VotingClassifier
ensemble_model = VotingClassifier(estimators=[('lgb', lgb_model), ('xgb', xgb_model)], voting='soft')
ensemble_model.fit(X_train, y_train_binary)

# Predictions using ensemble model
y_pred_ensemble = ensemble_model.predict(X_test)

# Calculate evaluation metrics
accuracy_ensemble = accuracy_score(y_test_binary, y_pred_ensemble)
precision_ensemble = precision_score(y_test_binary, y_pred_ensemble)
recall_ensemble = recall_score(y_test_binary, y_pred_ensemble)
f1_ensemble = f1_score(y_test_binary, y_pred_ensemble)

print("Ensemble Metrics:")
print("Accuracy:", accuracy_ensemble)
print("Precision:", precision_ensemble)
print("Recall:", recall_ensemble)
print("F1 Score:", f1_ensemble)

# Classification Report
print("Classification Report:")
print(classification_report(y_test_binary, y_pred_ensemble))

# Plotting
for col in dfPhase.columns:
    if col != 'class' and pd.api.types.is_numeric_dtype(dfPhase[col]):
        fig, ax = plt.subplots(2, 1, figsize=(10, 10))
        g1 = sns.boxenplot(x=dfPhase[col], ax=ax[0], color=custom_palette[2], linewidth=1.5)
        g2 = sns.stripplot(x=dfPhase[col], y=dfPhase['class'], ax=ax[1], hue=dfPhase['class'], palette=custom_palette, size=6, marker='o', alpha=0.7)
        ax[0].set_title(f"{col} Boxenplot")
        ax[0].set_xlabel(col)
        ax[1].set_title(f"{col} Stripplot")
        ax[1].set_xlabel(col)
        ax[1].set_ylabel("class")
        ax[0].spines['top'].set_visible(False)
        ax[0].spines['right'].set_visible(False)
        ax[1].spines['top'].set_visible(False)
        ax[1].spines['right'].set_visible(False)
        g2.legend(loc='upper right')
        plt.show()
